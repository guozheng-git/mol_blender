"""Install the pinned runtime into user-owned storage, never into Blender.app."""
from __future__ import annotations

import hashlib
import json
import os
import platform
import plistlib
import shutil
import subprocess
import sys
import tarfile
import tempfile
from pathlib import Path

from .config import config_root, runtime_versions


def fetch_verified(url, destination, sha256):
    destination = Path(destination)
    curl = "/usr/bin/curl" if sys.platform == "darwin" else "curl"
    subprocess.run([curl, "--fail", "--location", "--silent", "--show-error", "--proto", "=https", url, "--output", str(destination)], check=True)
    digest = hashlib.file_digest(destination.open("rb"), "sha256").hexdigest()
    if digest != sha256:
        destination.unlink(missing_ok=True)
        raise RuntimeError("Runtime download checksum mismatch")


def install(blender="", root=None):
    if sys.version_info[:2] != (3, 11):
        raise RuntimeError("Runtime setup requires Python 3.11 to match Blender's Python ABI.")
    root = Path(root) if root else config_root() / "runtime"
    root.mkdir(mode=0o700, parents=True, exist_ok=True)
    lock = runtime_versions()
    if not blender:
        target = "macos-arm64" if sys.platform == "darwin" and platform.machine() == "arm64" else "linux-x64" if sys.platform == "linux" and platform.machine() == "x86_64" else ""
        if not target:
            raise RuntimeError("Managed local runtime supports Apple Silicon Mac and Linux x86_64. Configure an existing compatible local runtime on other platforms.")
        artifact = lock["downloads"][target]
        with tempfile.TemporaryDirectory(prefix="blender-install-") as temporary:
            archive = Path(temporary) / artifact["filename"]
            fetch_verified(artifact["url"], archive, artifact["sha256"])
            if target == "macos-arm64":
                mounted = plistlib.loads(subprocess.check_output(["hdiutil", "attach", "-readonly", "-nobrowse", "-plist", str(archive)]))
                mount = next(item["mount-point"] for item in mounted["system-entities"] if "mount-point" in item)
                try:
                    destination = root / "Blender.app"
                    if destination.exists():
                        raise RuntimeError("Managed Blender.app already exists; inspect it before reinstalling.")
                    shutil.copytree(Path(mount) / "Blender.app", destination, symlinks=True)
                finally:
                    subprocess.run(["hdiutil", "detach", mount], check=True)
                blender = str(destination / "Contents/MacOS/Blender")
            else:
                with tarfile.open(archive) as source:
                    source.extractall(root, filter="data")
                blender = str(root / "blender-5.0.1-linux-x64/blender")
    site = root / "site"
    if subprocess.run([sys.executable, "-m", "pip", "--version"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL).returncode:
        subprocess.run([sys.executable, "-m", "ensurepip"], check=True)
    # Lock every wheel, including transitive dependencies. bpy is supplied by
    # Blender; never download a separate bpy wheel into the rendering runtime.
    subprocess.run([sys.executable, "-m", "pip", "install", "--no-deps", "--require-hashes", "--only-binary=:all:", "--target", str(site), "-r", str(Path(__file__).with_name("runtime-requirements.txt"))], check=True)
    env = os.environ.copy()
    env["PYTHONPATH"] = str(site)
    env["BLENDER_RENDER_CCD_SHA256"] = lock["ccd_sha256"]
    subprocess.run([blender, "--background", "--python-use-system-env", "--python-exit-code", "1", "--python", str(Path(__file__).with_name("runtime_initialize.py"))], env=env, check=True)
    return {"blender": blender, "runtime_site": str(site)}
